My name is Gerald Malkin and if you have this archive, I'm probably already dead.
I'm a former member of the Zohers organization, which is the most powerful group of people on the entire planet.
 
There are around a couple of thousand Zohers all over the world and their power is almost unlimited. They are responsible for multiple terrorist attacks, including the Detcelfer infection in 2013.
 
I was a member of this organization for almost 7 years, I'm not able to identify Zohers' main goal though. Each member takes part in some projects. The organization provides resources for the members?tasks and monitors the progress. If a member cannot complete the task, he or she gets the next one, but after 5 fails in a row the person disappears....
 
Zohers own a lot of small research companies, including Zsomething, which was my employer during my work on PRISM. Its goal was to create programmable virtual realities and force target people to 뱇ive?there. At first, I was really interested in working on this project, but then I realized that Zohers want to control people using VR technology. I couldn�?continue my work knowing that a lot of people will suffer, so I posted the description of the technology in my personal blog. Zohers were pissed off and hired some people to kill me. To my regret, I had already done too much and they had everything to finish the project. Zohers successfully tested it on PHDays CTF III participants and as the result the biggest information security corporations were out of service....
 
This archive was published automatically from my PC after 10 days of my unavailability. Here you can find all information about the tasks I worked on.
I really want to WARN you not to repeat my mistakes and to have nothing in common with Zohers!!!
Please, tell everyone about this organization and their activities to prevent deaths of innocent people!
 
R.I.P. Gerald Malkin
